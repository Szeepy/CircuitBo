const grid = document.getElementById('grid');
const gridSize = 10;
let currentComponent = null;
let circuit = Array(gridSize * gridSize).fill(null); // Initialize with null values
let debugMode = false; // Debug mode state

// Create the grid
function createGrid() {
    for (let i = 0; i < gridSize * gridSize; i++) {
        const cell = document.createElement('div');
        cell.classList.add('cell');
        cell.addEventListener('click', () => placeComponent(cell, i));
        grid.appendChild(cell);
    }
}
createGrid();

// Set current component to place
function setCurrentComponent(component) {
    currentComponent = component;
    document.querySelectorAll('#toolbar button').forEach(button => {
        button.classList.remove('active'); // Remove active class from all
    });
    document.getElementById(`${component}-btn`).classList.add('active'); // Add active class to the selected
}

document.getElementById('battery-btn').addEventListener('click', () => setCurrentComponent('battery'));
document.getElementById('bulb-btn').addEventListener('click', () => setCurrentComponent('bulb'));
document.getElementById('switch-btn').addEventListener('click', () => setCurrentComponent('switch'));
document.getElementById('resistor-btn').addEventListener('click', () => setCurrentComponent('resistor'));
document.getElementById('and-btn').addEventListener('click', () => setCurrentComponent('and-gate'));
document.getElementById('or-btn').addEventListener('click', () => setCurrentComponent('or-gate'));
document.getElementById('not-btn').addEventListener('click', () => setCurrentComponent('not-gate'));
document.getElementById('solar-btn').addEventListener('click', () => setCurrentComponent('solar-panel'));
document.getElementById('wire-btn').addEventListener('click', () => setCurrentComponent('wire'));
document.getElementById('clear-btn').addEventListener('click', clearGrid);
document.getElementById('save-btn').addEventListener('click', saveCircuit);
document.getElementById('load-btn').addEventListener('click', loadCircuit);
document.getElementById('debug-btn').addEventListener('click', toggleDebug);

// Place components in the grid
function placeComponent(cell, index) {
    if (!cell.hasChildNodes() && currentComponent) {
        const component = document.createElement('div');
        component.classList.add(currentComponent);
        cell.appendChild(component);

        circuit[index] = currentComponent;

        if (currentComponent === 'switch') {
            component.addEventListener('click', () => {
                component.classList.toggle('on');
                updatePower();
            });
        }

        updatePower();
    }
}

// Update power flow through the circuit
function updatePower() {
    const cells = document.querySelectorAll('.cell');
    const powerGrid = Array(gridSize * gridSize).fill(false);

    // Scan for power sources (battery and solar panel)
    circuit.forEach((component, index) => {
        if (component === 'battery' || component === 'solar-panel') {
            powerGrid[index] = true;
            spreadPower(index, powerGrid);
        }
    });

    // Handle AND gate logic
    circuit.forEach((component, index) => {
        if (component === 'and-gate') {
            const directions = [-1, 1, -gridSize, gridSize];
            let poweredInputs = 0;

            directions.forEach(dir => {
                const neighborIndex = index + dir;
                if (neighborIndex >= 0 && neighborIndex < gridSize * gridSize && powerGrid[neighborIndex]) {
                    poweredInputs++;
                }
            });

            if (poweredInputs >= 2) {
                powerGrid[index] = true;
                spreadPower(index, powerGrid);
            }
        }
    });

    // Handle resistor logic (blocks power)
    circuit.forEach((component, index) => {
        if (component === 'resistor') {
            powerGrid[index] = false; // Resistor blocks power
        }
    });

    // Update bulbs
    circuit.forEach((component, index) => {
        if (component === 'bulb') {
            const bulb = cells[index].firstChild;
            if (powerGrid[index]) {
                bulb.classList.add('on');
            } else {
                bulb.classList.remove('on');
            }
        }
    });

    // Debug mode highlighting
    if (debugMode) {
        cells.forEach((cell, index) => {
            if (powerGrid[index]) {
                cell.classList.add('debug');
            } else {
                cell.classList.remove('debug');
            }
        });
    }
}

// Spread power from power sources
function spreadPower(index, powerGrid) {
    const directions = [-1, 1, -gridSize, gridSize]; // left, right, up, down

    directions.forEach(dir => {
        const neighborIndex = index + dir;
        if (neighborIndex >= 0 && neighborIndex < gridSize * gridSize && (circuit[neighborIndex] === 'wire' || circuit[neighborIndex] === 'bulb')) {
            if (!powerGrid[neighborIndex]) {
                powerGrid[neighborIndex] = true;
                spreadPower(neighborIndex, powerGrid); // Recursively spread power
            }
        }
    });
}

// Clear the grid
function clearGrid() {
    const cells = document.querySelectorAll('.cell');
    cells.forEach(cell => {
        while (cell.firstChild) {
            cell.removeChild(cell.firstChild);
        }
    });
    circuit.fill(null); // Reset circuit array
    updatePower(); // Update power state
}

// Save circuit as JSON
function saveCircuit() {
    const dataStr = JSON.stringify(circuit);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'circuit.json';
    a.click();
    URL.revokeObjectURL(url);
}

// Load circuit from JSON
function loadCircuit() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = e => {
        const file = e.target.files[0];
        const reader = new FileReader();
        reader.onload = event => {
            circuit = JSON.parse(event.target.result);
            clearGrid();
            circuit.forEach((component, index) => {
                if (component) {
                    const cell = grid.children[index];
                    const componentDiv = document.createElement('div');
                    componentDiv.classList.add(component);
                    cell.appendChild(componentDiv);
                }
            });
            updatePower();
        };
        reader.readAsText(file);
    };
    input.click();
}

// Toggle debug mode
function toggleDebug() {
    debugMode = !debugMode;
    updatePower(); // Update power to reflect debug changes
}
